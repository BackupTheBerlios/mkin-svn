library(mkin)

source("R/mkinfit.R")
source("R/mkinmod.R")

m <- c("- k_parent_sink - k_parent_m1", 
    0, 
    "k_parent_m1",
    "-k_m1_sink")
matrix(m, nrow=2, byrow=TRUE)

f <- function(string)
{
  eval(parse(text=string), as.list(SFO_SFO.fit$par))
}
f <- function(string)
{
  eval(parse(text=string), as.list(odeparms))
}
m.n <- sapply(m, f)
m.n.m <- matrix(m.n, nrow=2, byrow=TRUE)
e <- eigen(m.n.m)
ini <- c(100,0)

c <- solve(e$vectors, ini)

f.out <- function(e, ini, t) {
  outer(ini[1] * e$vectors[,1], exp(e$values[1] * t)) +
  outer(ini[2] * e$vectors[,2], exp(e$values[2] * t))
}

t <- c(0)
f.out.2 <- function(t) {
  e$vectors %*% diag(exp(e$values * t)) %*% c
}
mapply(f.out.2, c(0, 3, 10, 100))

SFO_SFO.fit$data
out <- outer(c[1] * e$vectors[,1], exp(e$values[1] * t)) 
  outer(c[2] * e$vectors[,2], exp(e$values[2] * t))

# Debug SFO model
mkinmod <- SFO
observed <- FOCUS_2006_A
parms.ini <- rep(0.1, 1)
state.ini <- c(100)
fixed_parms <- NULL
fixed_initials <- character(0)
lower = 0
upper = Inf
plot = FALSE
quiet = FALSE
err = NULL
weight = "none"
scaleVar = FALSE
atol = 1e-6

P <- c(state.ini.optim, parms.optim)

# Debug SFORB model
mkinmod <- SFORB
observed <- FOCUS_2006_C
parms.ini <- rep(0.1, 3)
state.ini <- c(100,0)
lower = 0
upper = Inf
fixed_parms <- NULL
fixed_initials <- "parent_bound"
plot = FALSE
quiet = FALSE
err = NULL
weight = "none"
scaleVar = FALSE
atol = 1e-6

P <- c(state.ini.optim, parms.optim)
SFORB.fit <- mkinfit(SFORB, FOCUS_2006_C)
summary(SFORB.fit)

# Debug SFO_SFO model
mkinmod <- SFO_SFO
observed <- FOCUS_2006_D
parms.ini <- rep(0.1, 3)
state.ini <- c(100,0)
lower = 0
upper = Inf
fixed_parms <- NULL
fixed_initials <- "m1"
plot = FALSE
quiet = FALSE
err = NULL
weight = "none"
scaleVar = FALSE
atol = 1e-6
eigen = TRUE

P <- c(state.ini.optim, parms.optim)
SFO_SFO.fit <- mkinfit(SFO_SFO, FOCUS_2006_D, eigen=FALSE, plot=TRUE)
SFO_SFO.fit.eigen <- mkinfit(SFO_SFO, FOCUS_2006_D, eigen=TRUE, plot=TRUE)
summary(SFO_SFO.fit, data=FALSE)
summary(SFO_SFO.fit.eigen, data=FALSE)
summary(SFO_SFO.fit)

# Debug mkinplot
xlab = "Time"
ylab = "Observed"
xlim = range(fit$data$time)
ylim = range(fit$data$observed, na.rm=TRUE)
legend = TRUE
fit <- mkinfit(SFO, FOCUS_2006_A, plot=TRUE)
mkinplot(fit)
