###################################################
### chunk number 1: setup
###################################################
#line 22 "mkin.Rnw"
options(prompt = "R> ")
options(SweaveHooks = list(
  cex = function() par(cex.lab = 1.3, cex.axis = 1.3)))


###################################################
### chunk number 2: FOCUS_2006_C_data
###################################################
#line 85 "mkin.Rnw"
library("mkin")
FOCUS_2006_C


###################################################
### chunk number 3: data_format
###################################################
#line 104 "mkin.Rnw"
example_data <- data.frame(
  name = rep("parent", 9),
  time = c(0, 1, 3, 7, 14, 28, 63, 91, 119),
  value = c(85.1, 57.9, 29.9, 14.6, 9.7, 6.6, 4, 3.9, 0.6)
)


###################################################
### chunk number 4: model_definition
###################################################
#line 117 "mkin.Rnw"
SFO <- mkinmod(parent = list(type = "SFO"))
SFORB <- mkinmod(parent = list(type = "SFORB"))
SFO_SFO <- mkinmod(
  parent = list(type = "SFO", to = "m1", sink = TRUE),
  m1 = list(type = "SFO"))
SFORB_SFO <- mkinmod(
  parent = list(type = "SFORB", to = "m1", sink = TRUE),
  m1 = list(type = "SFO"))


###################################################
### chunk number 5: model_fitting
###################################################
#line 146 "mkin.Rnw"
# Do not show significance stars as they interfere with vignette generation
options(show.signif.stars = FALSE)
SFO.fit <- mkinfit(SFO, FOCUS_2006_C)
summary(SFO.fit)
SFORB.fit <- mkinfit(SFORB, FOCUS_2006_C)
summary(SFORB.fit)
SFO_SFO.fit <- mkinfit(SFO_SFO, FOCUS_2006_D, plot=TRUE)
summary(SFO_SFO.fit, data=FALSE)
SFORB_SFO.fit <- mkinfit(SFORB_SFO, FOCUS_2006_D, plot=TRUE)
summary(SFORB_SFO.fit, data=FALSE)


