#include <KApplication>
#include <KAboutData>
#include <KCmdLineArgs>
#include <KMessageBox>
#include <KLocale>

int main (int argc, char *argv[])
{
	KAboutData aboutData(
			"mkinGUI",
			0,
			ki18n("mkin GUI"),
			"0.5",
			ki18n("Creates and executes mkin R scripts"),
			KAboutData::License_GPL,
			ki18n("(c) 2011"),
			ki18n("Simple GUI for the mkin extension to the R software"),
			"http://developer.berlios.de/projects/mkin",
			"jranke@users.berlios.de");

	KCmdLineArgs::init( argc, argv, &aboutData );
	KApplication app;
	KGuiItem yesButton( i18n( "Hello" ), QString(),
			i18n( "This is a tooltip" ),
			i18n( "This is a WhatsThis help text." ) );
	KMessageBox::questionYesNo( 0, i18n( "Hello World" ),
			i18n( "Hello" ), yesButton );
	return 0;
}
