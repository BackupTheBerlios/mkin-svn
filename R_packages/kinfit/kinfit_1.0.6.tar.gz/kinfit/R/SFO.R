SFO <- function(t, parent.0, k)
{
	parent = parent.0 * exp(-k * t)
}
